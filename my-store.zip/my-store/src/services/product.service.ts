import { IProduct } from "../models/product";
import { DropdownOption } from "../components/dropdown/dropdown.model";
import { ProductSortOption } from "../enums/SortOptions";
const today = new Date();

export class ProductService {
  private static instance: ProductService;
  private productsList: IProduct[];
  private currentId: number;


  private constructor() {
    const data = JSON.parse(localStorage.getItem('productsStore') || '{}');
    this.productsList = data.productsList || [
      {
        creationDate: new Date(today.getDate()-2),
        name: 'Product 1',
        description: 'Product 1 Description',
        id: 1,
        price: 200,
      },
      {
        creationDate: new Date(today.getDate()-1),
        name: 'Product 2',
        description: 'Product 2 Description',
        id: 2,
        price: 400,
      },
      {
        creationDate: today,
        name: 'Product 3',
        description: 'Product 3 Description',
        id: 3,
        price: 500,
      }
    ];
    this.currentId = data.currentId || 4;
  }

  public static getInstance(): ProductService {
    if (!ProductService.instance) {
      ProductService.instance = new ProductService();
    }
    return ProductService.instance;
  }


  public fetchFilteredData(searchQuery:string, sortOption:ProductSortOption): IProduct[] {
    this.updateLocalStorage();
    let filteredProductsList = [...this.productsList];
    if (searchQuery) {
      filteredProductsList = filteredProductsList.filter((item) => item.name.includes(searchQuery) || item.description?.includes(searchQuery));
    }
    if (sortOption === ProductSortOption.ByName) {
      filteredProductsList.sort((a, b) => a.name.localeCompare(b.name));
    } else if(sortOption === ProductSortOption.ByRecentlyAdded) {
      filteredProductsList.sort((a, b) =>  b.creationDate.getTime() - a.creationDate.getTime());
    }
    return filteredProductsList;
  }

  public deleteProduct(id: number): void {
    const index = this.productsList.findIndex((product)=> product.id === id);
    if(index !== -1){
      this.productsList.splice(index, 1);
    }
    this.updateLocalStorage();
  };

  public addNewProduct(product: IProduct): void {
    product.id = this.currentId++;
    this.productsList.push(product);
    this.updateLocalStorage();
  };

  public editProduct(product: IProduct): void {
    const index = this.productsList.findIndex((item) => item.id === product.id);
    if(index !== -1){
      this.productsList[index] = {...product};
    }
    this.updateLocalStorage();
  };

  public getProductSortOptions(): DropdownOption[] {
    return [
      {label:'Name', value: ProductSortOption.ByName},
      {label:'Recently Added', value: ProductSortOption.ByRecentlyAdded}
    ];
  }

  private updateLocalStorage(): void {
    localStorage.setItem('productsStore', JSON.stringify({
      productsList: this.productsList,
      currentId: this.currentId,
    }));
  }
}