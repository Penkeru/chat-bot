export interface AppRouterProps {
  className?: string;
}