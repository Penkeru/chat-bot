export enum ProductSortOption {
  ByName = 'name',
  ByRecentlyAdded = 'recent'
}