import { css } from 'styled-components';
import { MainPageProps } from "./main-page.model";

export const MainPage = css<MainPageProps>(() => {
  return css`
    > .page-content{
      padding: 20px 40px;
      
      > .actions-container{
        display: flex;
        align-items: center;
        justify-content: flex-start;
        gap: 15px;
      }
      
      > .products-container{
        margin-top: 20px;
        width: 100%;
        height: calc(100vh - 200px);
        display: flex;
        gap: 20px;
        align-items: flex-start;
        
        > .products-list-container{
          width: 40%;
          overflow-y:auto;
          overflow-x: hidden;
        }
        
        > .product-details{
          width: 60%;
          position: relative;
          border: 1px solid #e0e0e0;
          overflow-y:auto;
          overflow-x: hidden;
        }
      }
    }
  `;
});