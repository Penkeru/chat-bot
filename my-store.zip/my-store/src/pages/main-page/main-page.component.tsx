import React, { useCallback, useEffect, useState } from 'react';
import styled from 'styled-components';
import { Header } from "../../components/header/header.component";
import { MainPageProps } from "./main-page.model";
import * as styles from "./main-page.style";
import { SearchBar } from "../../components/search-bar/search-bar.component";
import { Button } from "../../components/button/button.component";
import plusIcon from "../../assets/plus-icon.svg";
import { Dropdown } from "../../components/dropdown/dropdown.component";
import { DropdownOption } from "../../components/dropdown/dropdown.model";
import { ProductSortOption } from "../../enums/SortOptions";
import { IProduct } from "../../models/product";
import { ProductsList } from "../../components/products-list/products-list.component";
import { ProductForm } from "../../components/product-form/product-form.component";
import { ProductService } from "../../services/product.service";


export const MainPage = styled(({className}: MainPageProps) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortOption, setSortOption] = useState<ProductSortOption>(ProductSortOption.ByName);
  const [selectedProduct, setSelectedProduct] = useState<IProduct | null>(null);
  const [isNewProduct, setIsNewProduct] = useState<boolean>(false);
  const [productsList, setProductsList] = useState<IProduct[]>([]);

  const productServiceInstance = ProductService.getInstance();
  const sortOptions:DropdownOption[] = productServiceInstance.getProductSortOptions();


  const onSearchQueryChange = (value:string) => {
    setSearchQuery(value);
  };


  const onProductAddClick = () => {
    setSelectedProduct(null);
    setIsNewProduct(true);
  }

  const onSortSelected = (optionSelected:string) => {
    setSortOption(optionSelected as ProductSortOption);
  }

  const onProductDelete = (productId:number) => {
    productServiceInstance.deleteProduct(productId);
    getFilterResult();
  }

  const onProductFormSave = (product: IProduct) => {
    product.id === -1 ? productServiceInstance.addNewProduct(product) : productServiceInstance.editProduct(product)
    onProductFormClose();
    getFilterResult();
  }

  const onProductFormClose = () => {
    setIsNewProduct(false);
    setSelectedProduct(null);
  }

  const onProductSelect = (product: IProduct) => {
    setIsNewProduct(false);
    setSelectedProduct({...product});
  }

  const getFilterResult = useCallback(() => {
    setProductsList(productServiceInstance.fetchFilteredData(searchQuery, sortOption));
  },[searchQuery, sortOption, productServiceInstance]);

  useEffect(()=>{
    getFilterResult();
  },[searchQuery, sortOption, getFilterResult]);

  return <div {...{className}}>
    <Header title="My Store"/>
    <div className="page-content">
      <div className="actions-container">
        <Button label="Add" onClick={onProductAddClick} iconSrc={plusIcon}/>
        <SearchBar searchQuery={searchQuery} placeholder='Search Products' onSearchQueryChange={onSearchQueryChange} />
        <Dropdown label="Sort By:" options={sortOptions} onSelect={onSortSelected} selectedOption={sortOption}/>
      </div>
      <div className="products-container">
        <div className="products-list-container">
          <ProductsList productsList={productsList} onProductDelete={onProductDelete} onProductSelect={onProductSelect} selectedProductId={selectedProduct?.id || null}/>
        </div>
        {selectedProduct || isNewProduct ? (
          <div className="product-details">
            <ProductForm isNewProduct={isNewProduct} selectedProduct={selectedProduct} onProductSubmit={onProductFormSave} onCancel={onProductFormClose} />
          </div>
        ) : <></>}
      </div>
    </div>
  </div>
})`${styles.MainPage}`;