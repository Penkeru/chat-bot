export interface MainPageProps {
  className?: string;
}