import React from 'react';
import styled from 'styled-components';
import * as styles from './button.style';
import { ButtonProps } from './button.model';
import classNames from "classnames";

export const Button = styled(({className, iconSrc, label, onClick, disabled, buttonType = 'primary', type= 'button'}: ButtonProps) => {
  return (
    <button type={type} className={classNames(`btn btn-${buttonType}`, className)} disabled={disabled} onClick={onClick}>
      {iconSrc && <img src={iconSrc} alt={label}/>}
      {label}
    </button>
  );
})`${styles.Button}`;