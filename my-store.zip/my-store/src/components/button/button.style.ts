import { css } from 'styled-components';
import { ButtonProps } from './button.model';

export const Button = css<ButtonProps>(() => {
  return css`
    border: none;
    padding: 10px 20px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    font-size: 16px;
    font-weight: 500;
    transition: background-color 0.3s;
  `;
});