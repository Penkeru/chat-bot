import React, { useCallback, useEffect, useState } from 'react';
import styled from 'styled-components';
import * as styles from './dropdown.style';
import { DropdownProps } from './dropdown.model';

export const Dropdown = styled(({className, label, selectedOption, onSelect, options}: DropdownProps) => {
  const [selectedOptionLabel,setSelectOptionsLabel] = useState<string>();

  const handleOnSelect = useCallback((sort: string) => {
    onSelect(sort);
  },[onSelect]);

  useEffect(()=>{
    setSelectOptionsLabel(options.filter(option => option.value === selectedOption)[0].label);
  },[selectedOption, options]);

  return (
    <div {...{className}}>
      {label && <label>{label}</label>}
      <div className="dropdown">
        <button className="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown"
                aria-expanded="false">
          {selectedOptionLabel}
        </button>
        <ul className="dropdown-menu">
          {options.map((option, index) =>
             <li key={index}><button className="dropdown-item" onClick={() => handleOnSelect(option.value)}>{option.label}</button></li>
          )}
        </ul>
      </div>
    </div>
  );
})`${styles.Dropdown}`;