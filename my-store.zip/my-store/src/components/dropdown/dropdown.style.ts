import { css } from 'styled-components';
import { DropdownProps } from './dropdown.model';

export const Dropdown = css<DropdownProps>(({theme}) => {
  return css`
    display: flex;
    align-items: center;
    gap: 10px;
  `;
});