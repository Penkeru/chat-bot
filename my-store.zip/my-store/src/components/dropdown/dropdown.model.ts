export interface DropdownOption {
  label:string;
  value:string;
}


export interface DropdownProps {
  className?: string;
  label?:string;
  options: Array<DropdownOption>;
  selectedOption: string;
  onSelect: (option: string) => void;
}