import { IProduct } from "../../models/product";

export interface ProductFormProps {
  className?: string;
  selectedProduct?: IProduct | null;
  onProductSubmit: (product: IProduct) => void;
  isNewProduct: boolean;
  onCancel: () => void;
}