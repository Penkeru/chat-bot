import React, { useCallback } from 'react';
import styled from 'styled-components';
import * as styles from './product-form.style';
import { ProductFormProps } from './product-form.model';
import { Button } from "../button/button.component";
import cancelIcon from '../../assets/cancel-icon.svg';
import submitIcon from '../../assets/submit-icon.svg';
import { SubmitHandler, useForm } from "react-hook-form";
import { IProduct } from "../../models/product";

export const ProductForm = styled(({className, selectedProduct, isNewProduct, onCancel, onProductSubmit}: ProductFormProps) => {
  const {register, handleSubmit, formState:{errors,isValid}} = useForm<IProduct>({
    mode:'onChange',
    ...(!isNewProduct ? {
      values: {
        id: selectedProduct?.id || -1,
        name: selectedProduct?.name || '',
        description: selectedProduct?.description || '',
        price: selectedProduct?.price || 0,
        creationDate: selectedProduct?.creationDate || new Date(),
      }} : {defaultValues:{id: -1}})
    });


  const onSubmit: SubmitHandler<IProduct> = useCallback((data) => {
    onProductSubmit(data);
  },[onProductSubmit]);

  return (
    <form {...{className, onSubmit: handleSubmit(onSubmit)}}>
      <img className="form-image" src="https://placehold.co/60x60" alt="placeholder"/>
      <div className="form-group">
        <label htmlFor="product-name" >Name</label>
        <input className="form-control"
               id="product-name"
               placeholder="Product Name"
               {...register("name", { required: true, maxLength: 30 })}
        />
        <div className="error-message"> {errors.name && <span>Please enter a valid product name</span>}</div>
      </div>
      <div className="form-group">
        <label htmlFor="product-description" >Description</label>
        <textarea className="form-control"
                  id="product-description"
                  placeholder="Product Description"
                  {...register("description", { required: false, maxLength: 200 })}

        />
        <div className="error-message"> {errors.description && <span>Please enter a valid product description</span>}</div>
      </div>
      <div className="form-group">
        <label htmlFor="product-price">Price</label>
        <div className="input-container">
          <input className="form-control"
                 id="product-price"
                 placeholder="Product Price"
                 {...register("price", { required: true, min: 1, pattern: /^[0-9]+(\.[0-9]{1,2})?$/})}
          />
          <span>$</span>
        </div>
        <div className="error-message"> {errors.price && <span>Enter a valid price</span>} </div>
      </div>

      <div className="actions-container">
        <Button label="Cancel" onClick={onCancel} buttonType="danger" iconSrc={cancelIcon}/>
        <Button disabled={!isValid} label={isNewProduct ? 'Create' : 'Update'} buttonType="primary" iconSrc={submitIcon} type="submit"/>
      </div>
    </form>
  );
})`${styles.ProductForm}`;