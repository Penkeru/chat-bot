import { css } from 'styled-components';
import { ProductFormProps } from './product-form.model';

export const ProductForm = css<ProductFormProps>(({theme}) => {
  return css`
    display: flex;
    flex-direction: column;
    gap: 20px;
    padding: 20px;
    border-radius: 5px;
    margin-bottom: 15px;
    
    > .form-image {
      width: 60px;
      height: 60px;
    }
    
    > .form-group {
      display: flex;
      flex-direction: column;
      gap: 5px;

      > label {
        font-size: 14px;
        font-weight: 500;
        padding-left: 10px;
      }
      
      > .input-container{
        display: flex;
        align-items: center;
        gap: 10px;
        width: 200px;
      }
      
      > .error-message {
        height: 20px;
        > span{
          color: red;
          font-size: 12px;
        }
      }
    }
    
    > .actions-container{
      display: flex;
      align-items: center;
      justify-content: flex-end;
      gap: 15px;
      > button{
        padding: 5px 10px;
      }
    }
    
  `;
});