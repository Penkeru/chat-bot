import { IProduct } from "../../models/product";

export interface ProductsListProps {
  className?: string;
  productsList: IProduct[];
  onProductDelete: (productId: number) => void;
  onProductSelect: (product: IProduct) => void;
  selectedProductId: number | null;
}