import { css } from 'styled-components';
import { ProductsListProps } from './products-list.model';

export const ProductsList = css<ProductsListProps>(({theme}) => {
  return css`
    margin: 0;
    padding: 0;
    list-style-type: none;
    width: 100%;
  `;
});