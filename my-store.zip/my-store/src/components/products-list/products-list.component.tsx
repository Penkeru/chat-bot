import React from 'react';
import styled from 'styled-components';
import * as styles from './products-list.style';
import { ProductsListProps } from './products-list.model';
import { ProductItem } from "./product-item/product-item.component";

export const ProductsList = styled(({className, productsList, onProductDelete, onProductSelect, selectedProductId}: ProductsListProps) => {
  return <ul {...{className}}>
    {productsList.map((product, index) =>
      <li key={index}>
        <ProductItem product={product} onProductDelete={onProductDelete} onProductSelect={onProductSelect} selectedProductId={selectedProductId} />
      </li>
    )}
  </ul>
})`${styles.ProductsList}`;