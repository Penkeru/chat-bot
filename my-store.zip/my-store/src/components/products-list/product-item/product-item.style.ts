import { css } from 'styled-components';
import { ProductItemProps } from './product-item.model';

export const ProductItem = css<ProductItemProps>(({theme}) => {
  return css`
    display: flex;
    justify-content: flex-start;
    align-items: center;
    gap: 20px;
    padding: 10px 20px;
    border: 1px solid #e0e0e0;
    border-radius: 5px;
    margin-bottom: 15px;
    cursor: pointer;
    transition: all 0.3s;
    &:hover{
      background-color: #3563eb;
    }
    &.active{
      background-color: #3563eb;
      color: #ffffff;
    }
    
    > .product-image{
      flex: 0;
    }
    
    > .product-details{
      flex: 1;
    }
    
    
    > .product-actions{
      flex: 0;
      display: flex;
      align-items: flex-end;
      justify-content: flex-end;
      gap: 10px;
      > button {
        padding: 5px 10px;
        cursor: pointer;
        
      }
    }
  `;
});