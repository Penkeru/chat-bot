import { IProduct } from "../../../models/product";

export interface ProductItemProps {
  className?: string;
  product: IProduct;
  onProductDelete: (productId: number) => void;
  onProductSelect: (product: IProduct) => void;
  selectedProductId: number | null;
}