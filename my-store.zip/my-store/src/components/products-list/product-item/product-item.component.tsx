import React, { useCallback, useMemo } from 'react';
import styled from 'styled-components';
import * as styles from './product-item.style';
import { ProductItemProps } from './product-item.model';
import { Button } from "../../button/button.component";
import trashIcon from "../../../assets/trash-icon.svg";
import classNames from "classnames";

export const ProductItem = styled(({className, product, onProductDelete, onProductSelect, selectedProductId}: ProductItemProps) => {

  const handleDeleteClick = useCallback((event:React.MouseEvent<HTMLButtonElement>) => {
    event.stopPropagation();
    onProductDelete(product.id);
  },[onProductDelete, product]);

  const handleProductClick = useCallback(()=>{
    onProductSelect(product);
  },[onProductSelect, product]);

  const isProductSelected = useMemo(()=> selectedProductId === product.id,[selectedProductId, product]);

  return (<div className={classNames(className, {'active': isProductSelected})} onClick={handleProductClick}>
      <div className="product-image">
        <img src="https://placehold.co/60x60" alt={product.name}/>
      </div>
      <div className="product-details">
        <h4>{product.name}</h4>
        <p>{product.description}</p>
      </div>
      <div className="product-actions">
        <Button label="Delete" buttonType="danger" onClick={handleDeleteClick} iconSrc={trashIcon}/>
      </div>
  </div>)
})`${styles.ProductItem}`;