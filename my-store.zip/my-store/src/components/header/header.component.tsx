import React from 'react';
import styled from 'styled-components';
import * as styles from './header.style';
import { HeaderProps } from './header.model';

export const Header = styled(({className, title}: HeaderProps) => {
  return <div {...{className}}>
    <h2>{ title }</h2>
  </div>
})`${styles.Header}`;