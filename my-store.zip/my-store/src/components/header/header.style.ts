import { css } from 'styled-components';
import { HeaderProps } from './header.model';

export const Header = css<HeaderProps>(({theme}) => {
  return css`
    background: aliceblue;
    height: 80px;
    box-sizing: border-box;
    display: flex;
    align-items: center;
    padding: 0 40px;
    > h1 {
      margin: 0;
    }
  `;
});