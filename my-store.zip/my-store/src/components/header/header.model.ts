export interface HeaderProps {
  className?: string;
  title: string;
}