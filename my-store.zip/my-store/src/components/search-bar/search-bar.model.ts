export interface SearchBarProps {
  className?: string;
  searchQuery: string;
  placeholder?: string;
  onSearchQueryChange: (searchQuery: string) => void;
  timeout?: number;
}