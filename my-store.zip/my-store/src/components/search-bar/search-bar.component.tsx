import React, { useCallback } from 'react';
import styled from 'styled-components';
import * as styles from './search-bar.style';
import { SearchBarProps } from './search-bar.model';
import SearchIcon from '../../assets/search-icon.svg';

export const SearchBar = styled(({className, searchQuery, onSearchQueryChange, placeholder}: SearchBarProps) => {

  const onSearchChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {

    onSearchQueryChange(event.target.value);
  }, [onSearchQueryChange]);

  return (<div {...{className}}>
    <img src={SearchIcon} alt="search"/>
    <input type="text" value={searchQuery} onChange={onSearchChange} placeholder={placeholder}/>
  </div>);
})`${styles.SearchBar}`;