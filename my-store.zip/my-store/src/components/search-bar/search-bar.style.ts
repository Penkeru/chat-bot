import { css } from 'styled-components';
import { SearchBarProps } from './search-bar.model';

export const SearchBar = css<SearchBarProps>(() => {
  return css`
    display: flex;
    align-items: center;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    > input {
      border: none;
      outline: none;
      margin-left: 10px;
      font-size: 16px;
      color: #333;
    }
    
    > .fa-search {
      
    }
  `;
});