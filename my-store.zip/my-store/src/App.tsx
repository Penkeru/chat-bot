import React from 'react';
import { AppRouter } from "./routers/app-router/app-router.component";



export const App = () => {

  return (
    <div className="App">
      <AppRouter/>
    </div>
  );
}
